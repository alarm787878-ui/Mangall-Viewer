(function () {
  const modules = (globalThis.__dcmvModules = globalThis.__dcmvModules || {});
  const siteRegistry = globalThis.__dcmvSiteRegistry || {};
  // 원본 후보가 작은 오류 안내 이미지면 기존 이미지를 유지하기 위한 최소 기준.
  const MIN_REPLACEMENT_LONG_SIDE_WHEN_SOURCE_UNKNOWN = 800;
  const MIN_REPLACEMENT_AREA_WHEN_SOURCE_UNKNOWN = 500000;

  function shouldUseReplacementImage(item, width, height) {
    if (!width || !height) return false;

    const candidateLongSide = Math.max(width, height);
    const candidateArea = width * height;
    const sourceWidth = item?.width || 0;
    const sourceHeight = item?.height || 0;

    if (!item?.hasKnownSourceSize || !sourceWidth || !sourceHeight) {
      return (
        candidateLongSide >= MIN_REPLACEMENT_LONG_SIDE_WHEN_SOURCE_UNKNOWN &&
        candidateArea >= MIN_REPLACEMENT_AREA_WHEN_SOURCE_UNKNOWN
      );
    }

    return (
      candidateLongSide >= Math.max(sourceWidth, sourceHeight) &&
      candidateArea > sourceWidth * sourceHeight
    );
  }

  function getCurrentSiteAdapter() {
    return siteRegistry.getSiteAdapterForUrl?.(location.href) || null;
  }

  function getAdapterMethod(name, fallback) {
    const adapter = getCurrentSiteAdapter();
    if (adapter && typeof adapter[name] === "function") {
      return adapter[name].bind(adapter);
    }

    return fallback;
  }

  function compareDocumentOrder(a, b) {
    if (a === b) return 0;
    if (!(a instanceof Node) || !(b instanceof Node)) return 0;

    const position = a.compareDocumentPosition(b);
    if (position & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
    if (position & Node.DOCUMENT_POSITION_PRECEDING) return 1;
    return 0;
  }

  function getRootBranchElement(imgEl, root) {
    if (!(imgEl instanceof Element)) return null;
    if (!(root instanceof Element)) {
      return imgEl.parentElement || imgEl;
    }

    let branch = imgEl;
    let current = imgEl;
    while (current && current !== root) {
      branch = current;
      current = current.parentElement;
    }

    return branch;
  }

  function getRepairCurrentDisplayFingerprint(
    targetState,
    useSourceItems = false,
    includeSize = true
  ) {
    if (!targetState?.currentStep) return "";

    const step = targetState.currentStep;
    const images = (step.images || []).map((item) => {
      const sourceItem = useSourceItems
        ? targetState.sourceItems?.[item.index] || item
        : item;

      return [
        sourceItem.index,
        sourceItem.displayIndex,
        sourceItem.resolvedSrc || sourceItem.src || "",
        includeSize ? sourceItem.width || 0 : 0,
        includeSize ? sourceItem.height || 0 : 0,
        sourceItem.failed ? 1 : 0
      ].join(":");
    });

    return [
      targetState.totalCount || 0,
      targetState.stepIndex,
      step.displayType || "",
      step.startIndex,
      images.join(",")
    ].join("|");
  }

  function hasPendingViewerPageRender(targetState) {
    return !!targetState?.stage?.querySelector?.(":scope > .dcmv-page-wrap[data-dcmv-pending='1']");
  }

  function deferRepairRender(targetState, detail) {
    if (!targetState) return;

    targetState.deferredRepairRenderRequested = true;
    targetState.deferredRepairRenderReason = detail?.reason || "repair";
  }

  function renderOrDeferRepair(targetState, deps, detail) {
    if (!targetState || !detail?.shouldRender) return;

    if (hasPendingViewerPageRender(targetState)) {
      deferRepairRender(targetState, detail);
      return;
    }

    deps.renderCurrentStep();
    deps.syncHudTrigger();
  }

  modules.pageLoading = {
    findContentRoot() {
      const fallback = () => {
        const selectors = [
          ".fr-view.article-content",
          ".article-body .article-content",
          ".article-body",
          ".board-article .article-body",
          ".writing_view_box",
          ".write_div",
          ".view_content_wrap",
          ".view_content",
          ".gallview_contents",
          ".ub-content",
          "article",
          "main"
        ];

        for (const selector of selectors) {
          const el = document.querySelector(selector);
          if (el) return el;
        }

        return document.body;
      };

      return getAdapterMethod("findContentRoot", fallback)();
    },

    async collectSourceItems(root, deps) {
      const adapter = getCurrentSiteAdapter();
      if (adapter?.collectSourceItems) {
        const result = await adapter.collectSourceItems(root, deps);
        if (Array.isArray(result) && result.length > 0) {
          return result;
        }
      }

      // 폴백: 기본 img 태그 수집
      const domImages = Array.from(root.querySelectorAll("img")).sort(compareDocumentOrder);
      const blockOrder = [];
      const blockMap = new Map();

      for (const imgEl of domImages) {
        if (this.isInsideExcludedImageCommentArea(imgEl)) continue;
        if (this.isExcludedInlineDcconImage(imgEl)) continue;
        if (this.isInsideOpenGraphPreview(imgEl)) continue;

        const originalPopUrl =
          imgEl.closest("a[href]")?.href ||
          deps.parseOriginalPopUrlFromTag(imgEl.outerHTML || "");
        const normalSrc =
          imgEl.getAttribute("data-original") ||
          imgEl.getAttribute("data-src") ||
          imgEl.getAttribute("src") ||
          deps.resolveImageUrlFromTag(imgEl.outerHTML || "");

        const decodedSrc = deps.decodeHtml(normalSrc || "");
        const decodedPopUrl = deps.decodeHtml(originalPopUrl || "");
        const itemKey = decodedPopUrl || decodedSrc;

        if (!itemKey) continue;

        const blockEl = getRootBranchElement(imgEl, root);
        const blockKey = blockEl || imgEl;
        if (!blockMap.has(blockKey)) {
          blockMap.set(blockKey, []);
          blockOrder.push(blockKey);
        }
        blockMap.get(blockKey).push({
          src: decodedSrc || "",
          originalPopUrl: decodedPopUrl || "",
          resolvedSrc: "",
          width: imgEl.naturalWidth || Number(imgEl.getAttribute("width")) || 0,
          height: imgEl.naturalHeight || Number(imgEl.getAttribute("height")) || 0,
          alt: imgEl.getAttribute("alt") || "",
          element: imgEl,
          failed: false
        });
      }

      const result = [];
      for (const blockKey of blockOrder) {
        const items = blockMap.get(blockKey) || [];
        for (const item of items) {
          result.push({
            ...item,
            index: result.length,
            displayIndex: result.length + 1
          });
        }
      }

      return result;
    },

    isInsideExcludedImageCommentArea(el) {
      const fallback = (target) => {
        if (!(target instanceof Element)) return false;
        return !!target.closest(
          ".article-comment, .comment-list, .comment-item, .article-head, .article-profile"
        );
      };

      return getAdapterMethod("isInsideExcludedImageCommentArea", fallback)(el);
    },

    isExcludedInlineDcconImage(el) {
      const fallback = (target) => {
        if (!(target instanceof Element)) return false;
        return target.matches("img.written_dccon, img.emoticon");
      };

      return getAdapterMethod("isExcludedInlineDcconImage", fallback)(el);
    },

    isInsideOpenGraphPreview(el) {
      const fallback = (target) => {
        if (!(target instanceof Element)) return false;
        return !!target.closest("div.og-div, .article-link-card, .link-preview");
      };

      return getAdapterMethod("isInsideOpenGraphPreview", fallback)(el);
    },

    loadLastReadPosition(pageSessionKey) {
      try {
        const raw = window.sessionStorage.getItem(pageSessionKey);
        const saved = raw ? JSON.parse(raw) : null;
        if (!saved) return null;
        const currentPageKey = `${location.origin}${location.pathname}${location.search}`;
        if (saved.pageKey !== currentPageKey) {
          // 다른 회차로 이동한 뒤 예전 회차 기록이 되살아나지 않도록 바로 지운다.
          window.sessionStorage.removeItem(pageSessionKey);
          return null;
        }
        return saved;
      } catch {
        return null;
      }
    },

    getPrimaryAnchorItem(targetState) {
      if (!targetState?.currentStep?.images?.length) return null;

      if (targetState.currentStep.images.length === 1) {
        return targetState.currentStep.images[0];
      }

      return targetState.readingDirectionRTL
        ? targetState.currentStep.images[targetState.currentStep.images.length - 1]
        : targetState.currentStep.images[0];
    },

    normalizeComparableUrl(url, deps) {
      return deps.normalizeComparableUrl
        ? deps.normalizeComparableUrl(url, deps.locationHref)
        : !url
          ? ""
          : String(url);
    },

    getComparableUrlsForItem(item, deps) {
      if (!item) return [];

      const urls = [
        item.src,
        item.resolvedSrc,
        item.replacementCandidateSrc,
        item.originalPopUrl,
        item.element?.currentSrc,
        item.element?.getAttribute?.("src"),
        item.element?.getAttribute?.("data-src"),
        item.element?.getAttribute?.("data-original")
      ]
        .map((value) => deps.normalizeComparableUrl(value || ""))
        .filter(Boolean);

      return Array.from(new Set(urls));
    },

    findSourceItemIndexByUrl(targetUrl, deps) {
      if (!deps.state || !targetUrl) return -1;

      for (const item of deps.state.sourceItems) {
        if (deps.getComparableUrlsForItem(item).includes(targetUrl)) {
          return item.index;
        }
      }

      return -1;
    },

    getStableItemKey(item, deps) {
      const urls = deps.getComparableUrlsForItem(item);
      return urls[0] || "";
    },

    saveLastReadPosition(targetState, deps) {
      if (!targetState) return;

      const pageKey = `${location.origin}${location.pathname}${location.search}`;
      const nextPosition = {
        pageKey,
        index: deps.getSavedImageIndex(targetState)
      };

      try {
        window.sessionStorage.setItem(
          deps.pageSessionKey,
          JSON.stringify(nextPosition)
        );
      } catch {
      }
    },

    async hydrateImageMetadata(items, options, deps) {
      const orientationChangedPages = [];

      for (let i = 0; i < items.length; i += deps.imageMetadataBatchSize) {
        const batch = items.slice(i, i + deps.imageMetadataBatchSize);
        const results = await Promise.all(
          batch.map((item) => this.loadImageMetadata(item, options, deps))
        );

        for (const result of results) {
          if (result && result.orientationChanged) {
            orientationChangedPages.push(result.index);
          }
        }
      }

      return { orientationChangedPages };
    },

    loadImageMetadata(item, options = {}, deps) {
      return new Promise((resolve) => {
        let done = false;
        const prevLandscape = deps.isLandscapeLike(item.width, item.height);
        const previousResolvedSrc = item.resolvedSrc || "";

        const finish = (failed) => {
          if (done) return;
          done = true;
          clearTimeout(timer);

          const hasKnownSourceSize = !!(item.width && item.height);
          if (!item.width) item.width = 1200;
          if (!item.height) item.height = 1700;
          item.hasKnownSourceSize = hasKnownSourceSize;

          if (failed && !options.forceImageFailure) {
            item.failed = false;
          } else {
            item.failed = !!failed;
          }

          const replacementCandidateSrc =
            !item.failed && item.originalPopUrl
              ? deps.convertPopUrlToDirectImageUrl(item.originalPopUrl)
              : "";
          item.replacementCandidateSrc = replacementCandidateSrc;

          const resolveMetadata = () => {
            const nextLandscape = deps.isLandscapeLike(item.width, item.height);
            resolve({
              index: item.index,
              orientationChanged:
                (prevLandscape === null && nextLandscape !== null) ||
                (prevLandscape !== null &&
                  nextLandscape !== null &&
                  prevLandscape !== nextLandscape)
            });
          };

          if (
            !replacementCandidateSrc ||
            replacementCandidateSrc === item.src ||
            item.replacementCandidateRejected
          ) {
            item.resolvedSrc =
              previousResolvedSrc && previousResolvedSrc === replacementCandidateSrc
                ? previousResolvedSrc
                : "";
            resolveMetadata();
            return;
          }

          if (previousResolvedSrc === replacementCandidateSrc) {
            item.resolvedSrc = previousResolvedSrc;
            resolveMetadata();
            return;
          }

          // 고화질 후보는 화면 렌더 후가 아니라 메타데이터/repair 단계에서 미리 검증한다.
          item.isCheckingReplacementCandidate = true;
          let candidateDone = false;
          const candidateProbe = new Image();
          const finishCandidate = (accepted) => {
            if (candidateDone) return;
            candidateDone = true;
            clearTimeout(candidateTimer);
            item.isCheckingReplacementCandidate = false;
            if (!accepted) {
              item.resolvedSrc = "";
            }
            resolveMetadata();
          };

          candidateProbe.onload = () => {
            const candidateWidth = candidateProbe.naturalWidth || 0;
            const candidateHeight = candidateProbe.naturalHeight || 0;
            if (!shouldUseReplacementImage(item, candidateWidth, candidateHeight)) {
              item.replacementCandidateRejected = true;
              finishCandidate(false);
              return;
            }

            item.resolvedSrc = replacementCandidateSrc;
            item.width = candidateWidth || item.width;
            item.height = candidateHeight || item.height;
            item.hasKnownSourceSize = true;
            finishCandidate(true);
          };
          candidateProbe.onerror = () => {
            finishCandidate(false);
          };
          const candidateTimer = setTimeout(() => {
            finishCandidate(false);
          }, deps.imageMetadataTimeoutMs);

          try {
            candidateProbe.src = replacementCandidateSrc;
          } catch {
            item.replacementCandidateRejected = true;
            finishCandidate(false);
          }
        };

        const probe = new Image();

        probe.onload = () => {
          item.width = probe.naturalWidth || item.width || 1200;
          item.height = probe.naturalHeight || item.height || 1700;
          finish(false);
        };

        probe.onerror = () => {
          finish(false);
        };

        const timer = setTimeout(() => {
          finish(false);
        }, deps.imageMetadataTimeoutMs);

        try {
          probe.src = item.src || "";
        } catch {
          finish(false);
        }
      });
    },

    findElementForSourceItem(root, targetItem, deps) {
      if (!root || !targetItem) return null;

      const imgs = Array.from(root.querySelectorAll("img"));
      const targetKeys = deps.getComparableUrlsForItem
        ? deps.getComparableUrlsForItem(targetItem)
        : [deps.decodeHtml(targetItem.originalPopUrl || targetItem.src || "")].filter(Boolean);
      if (!targetKeys.length) return null;

      for (const imgEl of imgs) {
        const imgPopUrl = deps.parseOriginalPopUrlFromTag(imgEl.outerHTML || "");
        const imgUrls = deps.getComparableUrlsForItem
          ? deps.getComparableUrlsForItem({
              src: deps.decodeHtml(imgEl.currentSrc || imgEl.getAttribute("src") || ""),
              resolvedSrc: "",
              originalPopUrl: deps.decodeHtml(imgPopUrl || ""),
              element: imgEl
            })
          : [
              imgEl.currentSrc,
              imgEl.getAttribute("src"),
              imgEl.getAttribute("data-original"),
              imgEl.getAttribute("data-src"),
              imgPopUrl
            ]
              .map((value) => deps.decodeHtml(value || ""))
              .filter(Boolean);

        if (imgUrls.some((url) => targetKeys.includes(url))) {
          return imgEl;
        }
      }

      return null;
    },

    estimateRenderedImageHeight(root, item, contentWidth, deps) {
      const actualHeight = deps.getActualRenderedHeightForItem(root, item);
      if (actualHeight != null) {
        return actualHeight;
      }

      const width = Math.max(1, Number(item?.width) || 1);
      const height = Math.max(1, Number(item?.height) || 1);

      return contentWidth * (height / width);
    },

    getActualRenderedHeightForItem(root, item, deps) {
      const el = deps.findElementForSourceItem(root, item);
      if (!el || !document.contains(el)) return null;

      const rect = el.getBoundingClientRect();
      if (!rect.height || rect.height <= 1) return null;

      return rect.height;
    },

    estimateScrollTopForImageIndex(root, sourceItems, targetIndex, deps) {
      if (!root || !sourceItems?.length) return null;

      const rootRect = root.getBoundingClientRect();
      const currentScrollY = window.scrollY || window.pageYOffset;
      const rootTop = rootRect.top + currentScrollY;
      const contentWidth = Math.max(320, root.clientWidth || rootRect.width || 320);

      let y = rootTop;

      for (let i = 0; i < targetIndex; i += 1) {
        const item = sourceItems[i];
        y += deps.estimateRenderedImageHeight(root, item, contentWidth);
        y += 12;
      }

      return Math.max(0, Math.round(y));
    },

    async refreshSourceItemsFromDom(targetState, deps) {
      if (!targetState) {
        return { nextSourceItems: [], countChanged: false };
      }

      // sourceItems가 없거나 빈 배열이면 빈 결과 반환
      if (!targetState.sourceItems || !Array.isArray(targetState.sourceItems)) {
        const collectedItems = await deps.collectSourceItems(targetState.root);
        return { nextSourceItems: collectedItems || [], countChanged: true };
      }

      const prevItemsByKey = new Map();
      for (const item of targetState.sourceItems) {
        const key = deps.getStableItemKey(item);
        if (key) {
          prevItemsByKey.set(key, item);
        }
      }

      const collectedItems = await deps.collectSourceItems(targetState.root);
      const nextSourceItems = collectedItems.map((item) => {
        const prevItem = prevItemsByKey.get(deps.getStableItemKey(item));
        if (!prevItem) return item;

        const sameSrc = (prevItem.src || "") === (item.src || "");

        return {
          ...item,
          // lazy 로딩 뒤 DOM의 실제 src/크기가 바뀌면 새 값을 우선해야 양면/단면 판정이 갱신된다.
          resolvedSrc: sameSrc ? prevItem.resolvedSrc || item.resolvedSrc : item.resolvedSrc,
          replacementCandidateSrc: sameSrc
            ? prevItem.replacementCandidateSrc || item.replacementCandidateSrc
            : item.replacementCandidateSrc,
          replacementCandidateRejected: sameSrc
            ? prevItem.replacementCandidateRejected || item.replacementCandidateRejected
            : item.replacementCandidateRejected,
          width: item.width || prevItem.width,
          height: item.height || prevItem.height,
          hasKnownSourceSize: item.hasKnownSourceSize || prevItem.hasKnownSourceSize,
          failed: sameSrc ? prevItem.failed : item.failed,
          viewerRetryCount: sameSrc ? prevItem.viewerRetryCount || 0 : 0
        };
      });

      const countChanged = nextSourceItems.length !== targetState.sourceItems.length;

      return { nextSourceItems, countChanged };
    },

    applyRefreshedSourceItems(targetState, nextSourceItems) {
      if (!targetState) return;
      targetState.sourceItems = nextSourceItems;
      targetState.totalCount = nextSourceItems.length;
    },

    async retryMissingItems(targetState, deps) {
      if (!targetState || !targetState.sourceItems || !Array.isArray(targetState.sourceItems)) {
        return { orientationChangedPages: [] };
      }

      const missing = targetState.sourceItems.filter(
        (item) => item.failed || !item.width || !item.height
      );
      const orientationChangedPages = [];
      for (const item of missing) {
        const result = await deps.retrySourceItem(item);
        if (result?.orientationChanged) {
          orientationChangedPages.push(result.index);
        }
      }

      return { orientationChangedPages };
    },

    async retrySourceItem(item, deps) {
      if (!item) return;
      item.src = deps.appendCacheBust(item.src || item.resolvedSrc || "");
      return deps.loadImageMetadata(item);
    },

    async wakeLazyImages(root, deps) {
      if (!root) return;

      const scrollDocument = root.ownerDocument || document;
      const scrollWindow = scrollDocument.defaultView || window;
      const scrollingElement =
        scrollDocument.scrollingElement ||
        scrollDocument.documentElement ||
        scrollDocument.body;
      const startY =
        scrollWindow.scrollY ||
        scrollWindow.pageYOffset ||
        scrollingElement?.scrollTop ||
        0;

      const getScrollTop = () =>
        scrollWindow.scrollY ||
        scrollWindow.pageYOffset ||
        scrollingElement?.scrollTop ||
        0;
      const getScrollHeight = () =>
        Math.max(
          scrollingElement?.scrollHeight || 0,
          scrollDocument.documentElement?.scrollHeight || 0,
          scrollDocument.body?.scrollHeight || 0
        );
      const getViewportHeight = () =>
        scrollWindow.innerHeight ||
        scrollDocument.documentElement?.clientHeight ||
        scrollingElement?.clientHeight ||
        0;
      const getViewportWidth = () =>
        scrollWindow.innerWidth ||
        scrollDocument.documentElement?.clientWidth ||
        scrollingElement?.clientWidth ||
        0;
      const lockedElements = [
        scrollDocument.documentElement,
        scrollDocument.body,
        document.documentElement,
        document.body
      ].filter((el, index, list) => el && list.indexOf(el) === index);
      const originallyLockedElements = lockedElements.filter((el) =>
        el.classList?.contains("dcmv-lock-scroll")
      );
      const scrollToY = (y) => {
        // 일부 사이트는 window 스크롤 대신 scrollingElement를 직접 움직일 때만 lazy 로더가 반응한다.
        try {
          scrollWindow.scrollTo(0, y);
        } catch {
        }
        if (scrollingElement) {
          scrollingElement.scrollTop = y;
        }
      };
      const sendWheel = (deltaY) => {
        // 사이트가 wheel 이벤트를 기준으로 이미지를 깨우는 경우를 위한 물리 스크롤에 가까운 보조 입력.
        try {
          const event = new WheelEvent("wheel", {
            bubbles: true,
            cancelable: true,
            view: scrollWindow,
            deltaY,
            deltaMode: 0
          });
          // elementFromPoint를 쓰면 뷰어 오버레이가 이벤트를 받아 페이지가 넘어갈 수 있어서,
          // 실제 스크롤 담당 요소에만 보낸다.
          (scrollingElement || scrollDocument).dispatchEvent(event);
        } catch {
        }
      };

      try {
        for (const el of originallyLockedElements) {
          el.classList.remove("dcmv-lock-scroll");
        }

        scrollToY(0);
        await deps.sleep(deps.lazyWakeScrollDelayMs);

        let y = 0;
        let lastScrollY = -1;
        let stuckCount = 0;

        while (stuckCount < 2) {
          deps.pokeLazyImages(root);
          sendWheel(deps.lazyWakeScrollStep);
          scrollToY(y);
          await deps.sleep(deps.lazyWakeScrollDelayMs);

          const currentScrollY = getScrollTop();
          const maxY = Math.max(0, getScrollHeight() - getViewportHeight());
          if (currentScrollY <= lastScrollY) {
            stuckCount += 1;
          } else {
            stuckCount = 0;
            lastScrollY = currentScrollY;
          }

          if (maxY > 0 && currentScrollY >= maxY - 2) {
            break;
          }

          y = currentScrollY + deps.lazyWakeScrollStep;
        }

        deps.pokeLazyImages(root);
        scrollToY(startY);
        deps.pokeLazyImages(root);
      } finally {
        for (const el of originallyLockedElements) {
          el.classList.add("dcmv-lock-scroll");
        }
      }
    },

    pokeLazyImages(root) {
      const adapter = getCurrentSiteAdapter();
      const imgs = Array.from(root.querySelectorAll("img"));
      for (const img of imgs) {
        try {
          if (img.closest?.("#dcmv-overlay")) {
            continue;
          }
          const dataOriginal = img.getAttribute("data-original");
          const dataSrc = img.getAttribute("data-src");
          const currentSrc = img.getAttribute("src");

          if (!currentSrc && dataOriginal) {
            img.setAttribute("src", dataOriginal);
          } else if (!currentSrc && dataSrc) {
            img.setAttribute("src", dataSrc);
          }
        } catch {
        }
      }
      if (adapter && typeof adapter.pokeLazyImages === "function") {
        adapter.pokeLazyImages(root);
      }
    },

    scheduleInitialPostLazyRefresh(targetState, deps) {
      if (!targetState) return;

      deps.runInitialLazyRepair().catch(() => {});
    },

    async runInitialLazyRepair(targetState, deps) {
      if (!targetState) return;

      deps.setImageLoadingProgress(0.38);
      await deps.wakeLazyImages(targetState.root);
      deps.setHasAutoLazyWakeRun(true);
      deps.runInitialAutoWhenReady("lazy 깨우기 완료");
      deps.setImageLoadingProgress(0.62);

      if (!deps.getState()) return;

      await deps.waitForAllPagesReadyBeforeSecondPass(2000);

      if (!deps.getState()) return;

      deps.setImageLoadingProgress(0.82);
      await deps.initialPostLazyRefreshRound();
    },

    async initialPostLazyRefreshRound(targetState, deps) {
      if (!targetState) return;

      const refreshResult = await deps.refreshSourceItemsFromDom();
      const previousCount = targetState.totalCount;
      const previousRenderUrls = deps.getCurrentStepRenderUrls();
      const beforeDisplayFingerprint = getRepairCurrentDisplayFingerprint(
        targetState,
        false,
        false
      );
      let didChange = false;

      deps.applyRefreshedSourceItems(refreshResult.nextSourceItems);
      const metadataResult = targetState.sourceItems.length
        ? await deps.hydrateImageMetadata(targetState.sourceItems)
        : { orientationChangedPages: [] };
      const retryResult = await deps.retryMissingItems();

      if (targetState.autoFirstPageAdjust && !targetState.hasUserAdjustedFirstPageSingle) {
        const previousFirstPageSingle = targetState.firstPageSingle;
        targetState.firstPageSingle = deps.chooseInitialFirstPageSinglePreference(
          previousFirstPageSingle,
          { phase: "2차 판정" }
        );
        if (targetState.firstPageSingle !== previousFirstPageSingle) {
          didChange = true;
          targetState.didAutoAdjustFirstPageSingle = true;
          deps.saveAutoAdjustedFirstPageSingleValue(targetState.firstPageSingle);
          deps.showEdgeToast("첫 페이지가 단면 설정이 자동 조정 되었습니다.", 2000);
        }
        deps.syncToggleVisuals();
      }

      const currentAnchorIndex = deps.getCurrentAnchorIndex();
      const layoutChanged = deps.applyRebuiltLayoutIfChanged(currentAnchorIndex);
      const renderUrlsChanged = deps.didCurrentStepRenderUrlsChange(previousRenderUrls);

      if (!layoutChanged) {
        if (renderUrlsChanged) {
          deps.syncCurrentStepImagesFromSourceItems();
        }
      }

      const afterDisplayFingerprint = getRepairCurrentDisplayFingerprint(
        targetState,
        true,
        false
      );
      const currentDisplayChanged = beforeDisplayFingerprint !== afterDisplayFingerprint;
      const shouldRender =
        didChange ||
        layoutChanged ||
        renderUrlsChanged ||
        currentDisplayChanged;
      if (!layoutChanged && currentDisplayChanged && !renderUrlsChanged) {
        deps.syncCurrentStepImagesFromSourceItems();
      }

      const renderDecision = {
        reason: "initialPostLazyRefreshRound",
        shouldRender
      };
      renderOrDeferRepair(targetState, deps, renderDecision);
      deps.setImageLoadingProgress(1, { complete: true });
      if (
        refreshResult.countChanged ||
        metadataResult.orientationChangedPages.length ||
        retryResult.orientationChangedPages.length ||
        didChange ||
        layoutChanged
      ) {
        if (targetState.totalCount !== previousCount) {
          deps.showEdgeToast("이미지가 추가 확인되어 새로고침 하였습니다.", 2000);
        }
      }
    },

    scheduleBackgroundRepair(targetState, deps) {
      if (!targetState) return;

      deps.clearRepairTimers(targetState);

      for (let i = 0; i < deps.repairMaxRounds; i += 1) {
        const delay = deps.repairInitialDelayMs + deps.repairIntervalMs * i;
        const timer = setTimeout(() => {
          deps.backgroundRepairRound().catch(() => {});
        }, delay);
        targetState.repairTimers.push(timer);
      }
    },

    async backgroundRepairRound(targetState, deps) {
      if (!targetState || targetState.isRepairRunning) return;
      targetState.isRepairRunning = true;

      try {
        if (!targetState.backgroundLazyWakeCount) {
          await deps.wakeLazyImages(targetState.root);
          targetState.backgroundLazyWakeCount = 1;
        }
        if (!deps.getHasAutoLazyWakeRun()) {
          deps.setHasAutoLazyWakeRun(true);
        }

        const refreshResult = await deps.refreshSourceItemsFromDom();
        const previousRenderUrls = deps.getCurrentStepRenderUrls();
        const beforeDisplayFingerprint = getRepairCurrentDisplayFingerprint(
          targetState,
          false,
          false
        );

        deps.applyRefreshedSourceItems(refreshResult.nextSourceItems);
        const metadataResult = await deps.hydrateImageMetadata(targetState.sourceItems);
        const retryResult = await deps.retryMissingItems();

        const currentAnchorIndex = deps.getCurrentAnchorIndex();
        const layoutChanged = deps.applyRebuiltLayoutIfChanged(currentAnchorIndex);
        const renderUrlsChanged = deps.didCurrentStepRenderUrlsChange(previousRenderUrls);

        if (!layoutChanged) {
          if (renderUrlsChanged) {
            deps.syncCurrentStepImagesFromSourceItems();
          }
        }

        const afterDisplayFingerprint = getRepairCurrentDisplayFingerprint(
          targetState,
          true,
          false
        );
        const currentDisplayChanged = beforeDisplayFingerprint !== afterDisplayFingerprint;
        const shouldRender =
          layoutChanged ||
          renderUrlsChanged ||
          currentDisplayChanged;
        if (!layoutChanged && currentDisplayChanged && !renderUrlsChanged) {
          deps.syncCurrentStepImagesFromSourceItems();
        }

        const renderDecision = {
          reason: "backgroundRepairRound",
          shouldRender
        };
        renderOrDeferRepair(targetState, deps, renderDecision);
      } finally {
        if (deps.getState()) {
          deps.getState().isRepairRunning = false;
        }
      }
    },

    async runManualRefresh(targetState, deps) {
      if (!targetState || targetState.isRepairRunning || targetState.isManualRefreshRunning) {
        return;
      }
      targetState.isRepairRunning = true;
      targetState.isManualRefreshRunning = true;
      const hadManualPairingReset =
        Array.isArray(targetState.manualPairingResetIndices) &&
        targetState.manualPairingResetIndices.length > 0;
      targetState.manualPairingResetIndices = [];
      deps.clearSavedManualPairingResetIndices();
      deps.setRefreshButtonState(true);

      try {
        let didChange = hadManualPairingReset;

        await deps.wakeLazyImages(targetState.root);
        const refreshResult = await deps.refreshSourceItemsFromDom();
        const previousRenderUrls = deps.getCurrentStepRenderUrls();
        const beforeDisplayFingerprint = getRepairCurrentDisplayFingerprint(targetState);
        deps.applyRefreshedSourceItems(refreshResult.nextSourceItems);
        const metadataResult = await deps.hydrateImageMetadata(targetState.sourceItems);
        const retryResult = await deps.retryMissingItems();

        const currentAnchorIndex = deps.getCurrentAnchorIndex();
        const layoutChanged = deps.applyRebuiltLayoutIfChanged(currentAnchorIndex);
        const renderUrlsChanged = deps.didCurrentStepRenderUrlsChange(previousRenderUrls);

        if (!layoutChanged) {
          if (didChange) {
            deps.rebuildStepsKeepingAnchor(deps.getCurrentAnchorIndex());
          } else {
            deps.syncCurrentStepImagesFromSourceItems();
          }
        } else {
          didChange = true;
        }

        const afterDisplayFingerprint = getRepairCurrentDisplayFingerprint(targetState, true);
        const currentDisplayChanged = beforeDisplayFingerprint !== afterDisplayFingerprint;
        const shouldRender =
          didChange ||
          layoutChanged ||
          renderUrlsChanged ||
          currentDisplayChanged;

        const renderDecision = {
          reason: "runManualRefresh",
          shouldRender
        };
        renderOrDeferRepair(targetState, deps, renderDecision);
        if (didChange || layoutChanged) {
          deps.showEdgeToast("갱신 완료", 2000);
        }
      } finally {
        const state = deps.getState();
        if (state) {
          state.isRepairRunning = false;
          state.isManualRefreshRunning = false;
          deps.setRefreshButtonState(false);
        }
      }
    },

    clearRepairTimers(targetState) {
      const timers = targetState?.repairTimers || [];
      for (const timer of timers) {
        clearTimeout(timer);
      }
      if (targetState) {
        targetState.repairTimers = [];
      }
    },

    sleep(ms) {
      return new Promise((resolve) => setTimeout(resolve, ms));
    },

    async syncKnownDimensionsFromDom(targetState, deps) {
      if (!targetState?.root || !targetState?.sourceItems?.length) return;

      const refreshed = await deps.refreshSourceItemsFromDom();
      if (!refreshed?.nextSourceItems?.length) return;

      for (const nextItem of refreshed.nextSourceItems) {
        const currentItem = targetState.sourceItems[nextItem.index];
        if (!currentItem) continue;
        if (!currentItem.width && nextItem.width) {
          currentItem.width = nextItem.width;
        }
        if (!currentItem.height && nextItem.height) {
          currentItem.height = nextItem.height;
        }
      }
    },

    async waitForAllPagesReadyBeforeSecondPass(targetState, maxWaitMs, deps) {
      if (!targetState?.sourceItems?.length) return;

      const startedAt = Date.now();

      while (deps.getState()) {
        await deps.syncKnownDimensionsFromDom();

        const allReady = deps.getState().sourceItems.every((item) =>
          deps.hasUsableImageMetadata(item)
        );
        if (allReady) {
          return;
        }

        if (Date.now() - startedAt >= maxWaitMs) {
          return;
        }

        await new Promise((resolve) => {
          const timer = setTimeout(resolve, 80);
          deps.getState()?.repairTimers?.push(timer);
        });
      }
    },

    async ensureInitialAutoMetadataWindow(targetState, deps) {
      if (!targetState?.sourceItems?.length) return;
      if (targetState.initialAutoMetadataPromise) {
        await targetState.initialAutoMetadataPromise;
        return;
      }

      const targetItems = targetState.sourceItems
        .slice(0, deps.initialAutoRequiredKnownPages)
        .filter((item) => !item.width || !item.height || deps.isDcPlaceholderSize(item));

      if (!targetItems.length) {
        return;
      }

      targetState.initialAutoMetadataPromise = Promise.all(
        targetItems.map((item) => deps.loadImageMetadata(item))
      ).finally(() => {
        if (deps.getState()) {
          deps.getState().initialAutoMetadataPromise = null;
        }
      });

      await targetState.initialAutoMetadataPromise;
    },

    async runInitialAutoWhenReady(targetState, reason, deps) {
      if (!targetState || targetState.hasRunInitialAutoAfterFirstImageLoad) {
        return;
      }

      await deps.ensureInitialAutoMetadataWindow();
      await deps.syncKnownDimensionsFromDom();

      const rawEvaluationItems = targetState.sourceItems.slice(0, deps.initialAutoEvalPageLimit);
      const evaluationItems = rawEvaluationItems.map((item) =>
        deps.isDcPlaceholderSize(item)
          ? { ...item, width: 0, height: 0 }
          : item
      );
      const rawKnownSizeCount = rawEvaluationItems.filter((item) => item.width && item.height).length;
      const knownSizeCount = evaluationItems.filter((item) => item.width && item.height).length;
      const totalCount = targetState.sourceItems.length;
      const hasEnoughKnownPages = knownSizeCount >= deps.initialAutoRequiredKnownPages;
      const hasLoadedAllKnownPages =
        rawKnownSizeCount >= Math.min(totalCount, deps.initialAutoEvalPageLimit);

      if (!hasEnoughKnownPages && !hasLoadedAllKnownPages) {
        return;
      }

      targetState.hasRunInitialAutoAfterFirstImageLoad = true;

      const previousFirstPageSingle = targetState.firstPageSingle;
      const didChange = deps.applyInitialFirstPageSingleAuto(previousFirstPageSingle);
      if (didChange) {
        targetState.firstSingleCheckbox.checked = targetState.firstPageSingle;
        deps.syncToggleVisuals();
        deps.rebuildStepsKeepingAnchor(deps.getCurrentAnchorIndex());
        deps.renderCurrentStep();
        deps.syncHudTrigger();
      }

      await deps.presentInitialViewerAfterInitialAuto(didChange);
    },

    async presentInitialViewerAfterInitialAuto(targetState, didChange, deps) {
      if (!targetState || targetState.hasPresentedInitialViewer) {
        return;
      }

      await deps.sleep(5);
      if (!deps.getState() || deps.getState().hasPresentedInitialViewer) {
        return;
      }

      deps.getState().hasPresentedInitialViewer = true;
      deps.getState().stage.style.visibility = "";
      deps.setImageLoadingProgress(0.22);
      deps.showHudTemporarily();

      if (didChange) {
        deps.showEdgeToast("첫 페이지가 단면 설정이 자동 조정 되었습니다.", 2000);
      }
    }
  };
})();
